﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ownexception
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string text = textBox3.Text;
                if (text == "A+")
                {
                    MessageBox.Show("registered successfully");
                }
                if (text == "A")
                {
                    MessageBox.Show("registered successfully");
                }
                if (text == "B+")
                {
                    MessageBox.Show("registered successfully");
                }
                if (text == "B")
                {
                    MessageBox.Show("registered successfully");
                }
                if (text == "C+")
                {
                    MessageBox.Show("registered successfully");
                }
                if (text == "C")
                {
                    MessageBox.Show("registered successfully");
                }
                if (text == "F")
                {
                    MessageBox.Show("registered successfully");
                }
                else
                {
                    MessageBox.Show("Enter the right grade");
                }
            }
            catch(FormatException ea)
            {
                MessageBox.Show(ea.Message);
            }

        }
    }
}
