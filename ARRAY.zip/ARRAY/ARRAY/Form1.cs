﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ARRAY
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] a = new int[5];
            a[0] = int.Parse(textBox1.Text);
            a[1] = int.Parse(textBox2.Text);
            a[2] = int.Parse(textBox3.Text);
            a[3] = int.Parse(textBox4.Text);
            a[4] = int.Parse(textBox5.Text);
            for (int i = 0; i <5; i++)
            {
                label1.Text = label1.Text + " " + a[i];
            }
        }
    }
}
