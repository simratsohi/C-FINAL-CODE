﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace multipleforminterface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text;
            string City = textBox2.Text;

            Form2 simrat = new Form2(Name, City);

            Form2 obj = new Form2(Name,City);
            obj.MdiParent = this.ParentForm;
            obj.Show();
        }

        private void iTIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 obj = new Form3();
            obj.Show();
        }

        private void cONESTOGAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 hai = new Form3();
            hai.Show();
        }
    }
}
