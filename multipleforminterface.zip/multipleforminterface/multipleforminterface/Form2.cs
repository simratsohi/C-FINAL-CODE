﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace multipleforminterface
{
    public partial class Form2 : Form
    {
        string Name, City;
        public Form2(string n, string c)
        {
            InitializeComponent();
            Name = n;
            City = c; 
            label1.Text = n +" is from "+ c+" city";
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
