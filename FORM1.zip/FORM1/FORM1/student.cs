﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FORM1
{
    class student
    {
        String nameS;
        String[,] marks = { { "Simrat", "89" }{ "Harman", "65" }{ "Satwinder", "85" } };
        public Student(String stuname)
        {
            nameS = stuname;
        }
        public String getMarks()
        {
            String m = "Invalid Name";
            for(int i=0;i<3;i++)
            {
                m = "";
                if(marks[i,0]==nameS)
                {
                    m = marks[i, 1];
                }
            }

        }
    }
}
