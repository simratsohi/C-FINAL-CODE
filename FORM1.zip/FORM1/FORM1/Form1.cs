﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FORM1
{
    class Instructor
    {
        String showRemarks(int marks)
        {
            if(marks>70)
            {
                return "Excellent";
            }
            else
            {
                return "work hard";
            }

        }
    }
}
