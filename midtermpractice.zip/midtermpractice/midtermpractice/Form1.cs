﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace midtermpractice
{
    public partial class Form1 : Form
    {
        string []a =new string [4];
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string x = textBox1.Text;
            string y = textBox2.Text;

            string z = x + " " + y;

            label1.Text = z;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox3.Text);
            double y = double.Parse(textBox4.Text);

            double z = x + y;
            label3.Text = z.ToString();



        }

        private void button3_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox3.Text);
            double y = double.Parse(textBox4.Text);

            double z = x - y;
            label3.Text = z.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox3.Text);
            double y = double.Parse(textBox4.Text);

            double z = x * y;
            label3.Text = z.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string []x = { "simrat", "sahil", "anmol" };
            string []y = { "a", "b", "c" };

            for (int i=0;i<x.Length;i++)
            {
                if (textBox5.Text==x[i])
                {
                    MessageBox.Show(x[i] + " has got grade " + y[i]);
                }
               

            }
           
        }

        private void ontarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            obj.Show();
        }

        
        private void button6_Click(object sender, EventArgs e)
        {
            string x = textBox6.Text;
            Regex pattern = new Regex(@"[Ms,Mr,Mrs] \d\d$");

            if(pattern.IsMatch(x))
            {
                MessageBox.Show("match");
            }
            else
            {
                MessageBox.Show("not match");
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            pictureBox1.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            pictureBox1.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if(a[0] == "")
            {
               a[0]= textBox7.Text;
               comboBox1.Items.Add(a[0]);
            }
            else if(a[1]=="")
            {
                textBox7.Text = a[1];
                comboBox1.Items.Add(a[1]);
            }
            else if(a[2]=="")
            {
                textBox7.Text = a[2];
                comboBox1.Items.Add(a[2]);
            }
            else if(a[3]=="")
            {
                textBox7.Text = a[3];
                comboBox1.Items.Add(a[3]);
            }
            else
            {
                MessageBox.Show("dsdsaas");
            }

            for(int i=0;i<a.Length;i++)
            {
                a[i] = "";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(textBox8.Text);
                int b = int.Parse(textBox9.Text);

                int c = a / b;

                MessageBox.Show(c.ToString());
            }
            catch
            {
                MessageBox.Show("enter a valid number");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
